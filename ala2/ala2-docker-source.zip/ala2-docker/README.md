# ALA 2 - Virtualization with Docker
Two isolated container instances (vm-web1, vm-web2) with different CPU, memory and storage limits.
Run:  docker compose up -d --build
Stop: docker compose down
Open: http://localhost:8081 and http://localhost:8082

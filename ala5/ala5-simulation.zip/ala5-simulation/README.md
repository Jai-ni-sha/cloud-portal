# ALA 5 - Cloud performance optimization simulation
Requirements: Python 3, numpy, matplotlib
Run:  python ala5_simulation.py   (prints results, writes results.json)
Then: python figures.py           (draws the figures)

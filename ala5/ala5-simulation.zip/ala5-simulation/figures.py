import json, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

R = json.load(open("results.json"))
NAVY, BLUE, GREEN, ORANGE, RED, GREY = "#1F3A5F", "#2E75B6", "#2E8B57", "#E69500", "#C0392B", "#777777"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False, "axes.spines.right": False})

# ---------- helpers for diagrams
def box(ax, x, y, w, h, text, fc="#DCEBFA", ec=NAVY, fs=8.5, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08", fc=fc, ec=ec, lw=1.2))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, fontweight="bold" if bold else "normal", wrap=True)
def arrow(ax, x1, y1, x2, y2, text=None, color=NAVY, style="-|>", ls="-", tx=0, ty=0.12):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style, mutation_scale=12, color=color, lw=1.3, linestyle=ls))
    if text:
        ax.text((x1 + x2) / 2 + tx, (y1 + y2) / 2 + ty, text, ha="center", fontsize=7.5, style="italic", color=color)

# ---------- Figure 1: proposed architecture
fig, ax = plt.subplots(figsize=(10, 5.6)); ax.set_xlim(0, 10); ax.set_ylim(0, 5.6); ax.axis("off")
box(ax, 0.1, 2.3, 1.2, 0.9, "Users\n(web / mobile)", "#FFFFFF")
box(ax, 1.65, 2.3, 1.3, 0.9, "Route 53\n(DNS)", "#E8F5E9")
box(ax, 3.3, 2.3, 1.45, 0.9, "CloudFront\nedge cache", "#E8F5E9", bold=True)
box(ax, 5.1, 2.3, 1.45, 0.9, "Application Load\nBalancer\n(least outstanding\nrequests)", "#FFF4E5", bold=True, fs=7.5)
ax.add_patch(FancyBboxPatch((6.9, 1.3), 2.1, 2.9, boxstyle="round,pad=0.02,rounding_size=0.08", fc="#F7FAFD", ec=BLUE, lw=1.2, ls="--"))
ax.text(7.95, 3.93, "Auto Scaling group (2+ AZs)", ha="center", fontsize=7.5, color=BLUE, fontweight="bold")
box(ax, 7.1, 2.9, 1.7, 0.85, "EC2 instances\nAZ-a (web/app)", "#DCEBFA")
box(ax, 7.1, 1.55, 1.7, 0.85, "EC2 instances\nAZ-b (web/app)", "#DCEBFA")
box(ax, 7.1, 0.1, 1.7, 0.8, "ElastiCache +\nRDS Multi-AZ", "#F3E5F5")
box(ax, 3.3, 0.1, 3.25, 1.0, "Amazon CloudWatch\nmetrics: CPUUtilization, RequestCountPerTarget,\nTargetResponseTime, 5XX count, healthy hosts", "#FFFDE7", ec=ORANGE, fs=7.5)
box(ax, 3.3, 4.2, 3.25, 1.1, "Scaling policies\ntarget tracking (60% CPU) + predictive + scheduled\nalarms notify the on-call team", "#FFF4E5", ec=ORANGE, fs=7.5)
box(ax, 0.1, 4.2, 2.9, 1.1, "Edge / fog tier (optional)\nLocal Zones, Wavelength, Outposts\nfor latency-critical and IoT workloads", "#EDE7F6", ec="#5E35B1", fs=7.5)
arrow(ax, 1.3, 2.75, 1.65, 2.75); arrow(ax, 2.95, 2.75, 3.3, 2.75); arrow(ax, 4.75, 2.75, 5.1, 2.75, "cache miss", ty=0.55)
arrow(ax, 6.55, 2.75, 6.9, 3.3); arrow(ax, 6.55, 2.75, 6.9, 2.0)
arrow(ax, 7.95, 1.55, 7.95, 0.9)
arrow(ax, 6.9, 1.7, 6.55, 0.9, "metrics", color=ORANGE, ls="--", tx=0.5, ty=-0.28)
arrow(ax, 4.9, 1.1, 4.9, 2.3, color=ORANGE, ls="--")
arrow(ax, 4.9, 3.2, 4.9, 4.2, color=ORANGE, ls="--")
arrow(ax, 6.55, 4.6, 7.95, 4.2, "launch / terminate", color=ORANGE, ls="--", ty=0.25)
arrow(ax, 2.0, 4.2, 2.3, 3.2, "nearest\nnode", color="#5E35B1", ls=":", tx=-0.25, ty=0.1)
fig.savefig("fig1_architecture.png", dpi=200, bbox_inches="tight"); plt.close(fig)

# ---------- Figure 2: control loop
fig, ax = plt.subplots(figsize=(10, 3.3)); ax.set_xlim(0, 10); ax.set_ylim(0, 3.3); ax.axis("off")
steps = ["1. Workload\nchanges", "2. Metrics\npublished\n(60 s)", "3. Policy\ncompares metric\nwith target", "4. Instances\nlaunched /\nterminated", "5. Warm-up\n(boot + app\nstart)", "6. Load balancer\nregisters\ntargets"]
cols = ["#FFFFFF", "#FFFDE7", "#FFF4E5", "#DCEBFA", "#FFEBEE", "#E8F5E9"]
for i, (s, c) in enumerate(zip(steps, cols)):
    x = 0.1 + i * 1.65
    box(ax, x, 1.2, 1.4, 1.2, s, c, fs=8)
    if i < len(steps) - 1: arrow(ax, x + 1.4, 1.8, x + 1.65, 1.8)
ax.annotate("", xy=(0.8, 0.75), xytext=(9.2, 0.75), arrowprops=dict(arrowstyle="-|>", color=ORANGE, ls="--", lw=1.3))
ax.text(5, 0.35, "Feedback loop: new capacity changes utilization, which changes the next metric. Delays in steps 2 and 5 cause late scaling.", ha="center", fontsize=8, color=ORANGE, style="italic")
fig.savefig("fig2_loop.png", dpi=200, bbox_inches="tight"); plt.close(fig)

# ---------- Figure 3: load balancing
fig, ax = plt.subplots(figsize=(8, 4.2))
loads = [0.5, 0.7, 0.8, 0.9]
styles = {"round_robin": ("Round robin", RED, "o"), "random": ("Random", GREY, "s"),
          "weighted_round_robin": ("Weighted round robin", ORANGE, "^"), "least_outstanding": ("Least outstanding requests", GREEN, "D")}
for p, (lab, c, m) in styles.items():
    y = [R["lb"][str(u)][p]["p95"] for u in loads]
    ax.plot([int(u * 100) for u in loads], y, marker=m, color=c, label=lab, lw=1.8)
    for u, v in zip(loads, y):
        if R["lb"][str(u)][p]["unstable"]:
            ax.annotate("unstable", (int(u * 100), v), textcoords="offset points", xytext=(-30, -14), fontsize=7, color=c)
ax.set_yscale("log"); ax.set_xlabel("Offered load (% of total server capacity)"); ax.set_ylabel("p95 latency (ms, log scale)")
ax.set_xticks([50, 70, 80, 90]); ax.grid(alpha=0.3, which="both"); ax.legend(frameon=False)
fig.savefig("fig3_lb.png", dpi=200, bbox_inches="tight"); plt.close(fig)

# ---------- Figure 4: workload and capacity
hours = np.arange(1440) / 60
dem = np.array(R["demand_day3"])
fig, axs = plt.subplots(2, 1, figsize=(10, 6.2), sharex=True, gridspec_kw={"height_ratios": [1.5, 1]})
ax = axs[0]
ax.fill_between(hours, dem, color="#BFD7EE", label="Demand (requests/s)")
for s, lab, c in (("static_avg", "Static (sized for average)", RED), ("reactive", "Reactive target tracking", ORANGE), ("predictive", "Predictive + reactive", GREEN)):
    cap = np.array(R["as"][s]["in_service"]) * 100
    ax.plot(hours, cap, color=c, lw=1.6, label=lab + " capacity")
ax.set_ylabel("requests per second"); ax.legend(frameon=False, fontsize=8, loc="upper left")
ax.annotate("recurring flash sale\n(20:00)", (20.2, 2500), xytext=(14.2, 2750), arrowprops=dict(arrowstyle="->", color=GREY), fontsize=8)
ax.annotate("unforecast surge\n(13:00)", (13.1, 1900), xytext=(6.2, 2200), arrowprops=dict(arrowstyle="->", color=GREY), fontsize=8)
ax = axs[1]
for s, lab, c in (("static_avg", "Static (average)", RED), ("reactive", "Reactive", ORANGE), ("predictive", "Predictive + reactive", GREEN)):
    ax.plot(hours, np.minimum(np.array(R["as"][s]["rho"]) * 100, 200), color=c, lw=1.3, label=lab)
ax.axhline(85, color="k", ls="--", lw=1); ax.text(0.2, 88, "85% utilization = p95 latency limit (200 ms)", fontsize=7.5)
ax.axhline(60, color=GREY, ls=":", lw=1); ax.text(0.2, 62, "60% target", fontsize=7.5, color=GREY)
ax.set_ylabel("CPU utilization (%)\n(capped at 200)"); ax.set_xlabel("hour of day"); ax.set_xlim(0, 24); ax.set_xticks(range(0, 25, 3))
fig.savefig("fig4_workload.png", dpi=200, bbox_inches="tight"); plt.close(fig)

# ---------- Figure 5: cost vs violations
names = ["static_avg", "static_peak", "reactive", "predictive", "predictive_edge"]
labels = ["Static\n(average)", "Static\n(peak)", "Reactive", "Predictive\n+ reactive", "Predictive\n+ edge"]
base = R["as"]["static_peak"]["instance_hours"]
cost = [100 * R["as"][n]["instance_hours"] / base for n in names]
viol = [R["as"][n]["slo_violation_min"] for n in names]
fig, axs = plt.subplots(1, 2, figsize=(10, 3.9))
b = axs[0].bar(labels, cost, color=[RED, GREY, ORANGE, GREEN, BLUE])
for r_, v in zip(b, cost): axs[0].text(r_.get_x() + r_.get_width() / 2, v + 1.5, "%.1f%%" % v, ha="center", fontsize=8)
axs[0].set_ylabel("relative cost (static peak = 100%)"); axs[0].set_ylim(0, 115); axs[0].tick_params(axis="x", labelsize=8)
b = axs[1].bar(labels, viol, color=[RED, GREY, ORANGE, GREEN, BLUE])
for r_, v in zip(b, viol): axs[1].text(r_.get_x() + r_.get_width() / 2, v + 3, str(v), ha="center", fontsize=8)
axs[1].set_ylabel("minutes with p95 latency above 200 ms"); axs[1].set_ylim(0, 230); axs[1].tick_params(axis="x", labelsize=8)
fig.savefig("fig5_cost.png", dpi=200, bbox_inches="tight"); plt.close(fig)

# ---------- Figure 6: warm-up sensitivity
fig, ax = plt.subplots(figsize=(7, 3.6))
w = [1, 3, 5, 10]
for s, lab, c in (("reactive", "Reactive target tracking", ORANGE), ("predictive", "Predictive + reactive", GREEN)):
    ax.plot(w, [R["sens"][str(x)][s]["slo_violation_min"] for x in w], marker="o", color=c, label=lab, lw=1.8)
ax.set_xlabel("instance warm-up time (minutes)"); ax.set_ylabel("minutes above 200 ms p95"); ax.set_xticks(w); ax.grid(alpha=0.3); ax.legend(frameon=False)
fig.savefig("fig6_warmup.png", dpi=200, bbox_inches="tight"); plt.close(fig)
print("done")

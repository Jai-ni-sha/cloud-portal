"""ALA 5 - Cloud performance optimization: simulation of load balancing and auto-scaling.
Author: Jainisha Makwana (20230905090017)

Part 1: load-balancing algorithms (event simulation of 6 servers).
Part 2: auto-scaling strategies over a 3-day synthetic workload (1-minute steps).
All parameters are ASSUMPTIONS for a simulated scenario, not measurements of a real system.
"""
import heapq, json, math, random
from collections import deque
import numpy as np

# ---------------------------------------------------------------- Part 1
def simulate_lb(policy, utilization, n_req=120_000, seed=7):
    """6 servers: 4 fast (capacity 1.0) and 2 slower (capacity 0.75).
    Requests arrive as a Poisson process; service time is log-normal (heavy tail).
    Each server handles one request at a time (FIFO)."""
    rng = np.random.default_rng(seed)
    caps = np.array([1, 1, 1, 1, 0.75, 0.75])
    base_service = 0.100                       # 100 ms on a capacity-1.0 server
    mean_service = base_service / caps          # seconds per request on each server
    sigma = 1.0                                 # log-normal shape (CV about 1.3)
    total_rate = caps.sum() / base_service      # requests per second at 100% load
    lam = utilization * total_rate
    arrivals = np.cumsum(rng.exponential(1 / lam, n_req))
    free_at = np.zeros(len(caps))               # time each server becomes free
    outstanding = [deque() for _ in caps]       # completion times of outstanding requests
    rr = 0
    latencies = np.empty(n_req)
    w_int = (caps * 4).astype(int)                      # weights 4:4:4:4:3:3
    weights = np.array([k for r in range(w_int.max()) for k in range(len(caps)) if w_int[k] > r])  # interleaved pattern
    for i, t in enumerate(arrivals):
        for q in outstanding:
            while q and q[0] <= t:
                q.popleft()
        if policy == "round_robin":
            s = rr % len(caps); rr += 1
        elif policy == "random":
            s = int(rng.integers(len(caps)))
        elif policy == "weighted_round_robin":
            s = int(weights[rr % len(weights)]); rr += 1
        elif policy == "least_outstanding":
            counts = [len(q) for q in outstanding]
            m = min(counts)
            s = next(k for k, c in enumerate(counts) if c == m)
        else:
            raise ValueError(policy)
        svc = rng.lognormal(math.log(mean_service[s]) - sigma ** 2 / 2, sigma)
        start = max(t, free_at[s])
        free_at[s] = start + svc
        outstanding[s].append(free_at[s])
        latencies[i] = free_at[s] - t
    lat = latencies[n_req // 10:] * 1000        # drop warm-up, convert to ms
    # an equal-share policy is unstable when its per-server share exceeds the slowest server's capacity
    unstable = policy in ("round_robin", "random") and (lam / len(caps)) > (caps.min() / base_service)
    return {"mean": float(lat.mean()), "p95": float(np.percentile(lat, 95)), "p99": float(np.percentile(lat, 99)),
            "unstable": bool(unstable)}

# ---------------------------------------------------------------- Part 2
MU = 100.0          # requests per second one instance can serve
TARGET = 0.60       # target utilization of the scaling policy
WARMUP = 3          # minutes before a new instance serves traffic (boot + app start-up)
SCALE_IN_DELAY = 10 # minutes the metric must stay low before scaling in
MIN_N, MAX_N = 3, 120
SLO_P95_MS = 200    # illustrative service objective: p95 latency <= 200 ms
SERVICE_MS = 1000 / MU

def gauss(t, c, w):
    return np.exp(-((t - c) / w) ** 2)

def make_workload(days=3, seed=11):
    """Requests per second, one value per minute. Contains a daily pattern, a recurring flash sale
    at 20:00 (every day) and one UNFORECAST surge at 13:00 on the last day."""
    rng = np.random.default_rng(seed)
    t = np.arange(days * 1440)
    hour = (t % 1440) / 60
    d = 300 + 700 * gauss(hour, 21, 3) + 400 * gauss(hour, 13, 2.5)
    minute = t % 1440
    sale = np.where((minute >= 1200) & (minute < 1230), 1500.0, 0.0)
    ramp = np.where((minute >= 1198) & (minute < 1200), 750.0, 0.0)
    d = d + sale + ramp
    surge = np.zeros_like(d)
    last = (t >= (days - 1) * 1440)
    m3 = t - (days - 1) * 1440
    surge[last & (m3 >= 780) & (m3 < 800)] = 1200.0
    surge[last & (m3 >= 778) & (m3 < 780)] = 600.0
    d = d + surge
    d = d * rng.normal(1.0, 0.03, d.size)
    return np.maximum(d, 50.0)

def p95_latency_ms(rho):
    """M/M/1 approximation per instance: p95 = ln(20) * S / (1 - rho)."""
    rho = np.minimum(rho, 0.995)
    return math.log(20) * SERVICE_MS / (1 - rho)

def run_strategy(name, demand, edge_offload=0.0, warmup=WARMUP):
    n_total = demand.size
    d = demand * (1 - edge_offload)             # origin load after edge/CDN offload
    in_service = np.zeros(n_total)
    pending = deque()                           # (ready_minute, count)
    n_active = {"static_avg": None}
    n = 0
    if name == "static_avg":
        n = int(math.ceil(d[: 1440].mean() / (MU * TARGET)))
    elif name == "static_peak":
        n = int(math.ceil(d[: 1440 * 2].max() / (MU * TARGET)))
    elif name in ("reactive", "predictive", "predictive_edge"):
        n = MIN_N * 2
    low_counter = 0
    billed = np.zeros(n_total)
    for t in range(n_total):
        while pending and pending[0][0] <= t:
            n += pending.popleft()[1]
        in_service[t] = n
        n_pending = sum(c for _, c in pending)
        billed[t] = n + n_pending
        if name.startswith("static"):
            continue
        observed = d[max(t - 1, 0)]             # metric lag: last completed minute
        desired = int(math.ceil(observed / (MU * TARGET)))
        if name.startswith("predictive") and t >= 1440:
            window = d[t - 1440 + 1: t - 1440 + warmup + 3]
            desired = max(desired, int(math.ceil(1.1 * window.max() / (MU * TARGET))))
        desired = min(max(desired, MIN_N), MAX_N)
        have = n + n_pending
        if desired > have:
            pending.append((t + warmup, desired - have)); low_counter = 0
        elif desired < n:
            low_counter += 1
            if low_counter >= SCALE_IN_DELAY:
                n -= max(1, int(math.ceil(0.10 * (n - desired))))
        else:
            low_counter = 0
    last = slice(2 * 1440, 3 * 1440)            # evaluate the third day
    rho = d[last] / (in_service[last] * MU)
    served = np.minimum(d[last], in_service[last] * MU)
    lat = p95_latency_ms(rho)
    viol = (lat > SLO_P95_MS)
    sale_w = slice(1195, 1262)      # flash sale 20:00 (recurring)
    surge_w = slice(775, 830)       # unforecast surge 13:00
    return {
        "name": name,
        "viol_sale": int(viol[sale_w].sum()), "viol_surge": int(viol[surge_w].sum()),
        "instance_hours": float(billed[last].sum() / 60),
        "mean_util_pct": float(100 * rho.mean()),
        "max_util_pct": float(100 * rho.max()),
        "slo_violation_min": int((lat > SLO_P95_MS).sum()),
        "overload_min": int((rho > 1).sum()),
        "dropped_pct": float(100 * (1 - served.sum() / d[last].sum())),
        "worst_p95_ms": float(lat.max()),
        "in_service": in_service[last].tolist(),
        "demand_origin": d[last].tolist(),
        "rho": rho.tolist(),
    }

if __name__ == "__main__":
    out = {"lb": {}, "as": {}}
    for u in (0.5, 0.7, 0.8, 0.9):
        out["lb"][str(u)] = {p: simulate_lb(p, u) for p in
                             ("round_robin", "random", "weighted_round_robin", "least_outstanding")}
    demand = make_workload()
    out["demand_day3"] = demand[2 * 1440:].tolist()
    for s in ("static_avg", "static_peak", "reactive", "predictive"):
        out["as"][s] = run_strategy(s, demand)
    out["as"]["predictive_edge"] = run_strategy("predictive_edge", demand, edge_offload=0.40)
    out["sens"] = {}
    for w in (1, 3, 5, 10):
        out["sens"][str(w)] = {s_: {k: v for k, v in run_strategy(s_, demand, warmup=w).items()
                                   if k in ("slo_violation_min", "overload_min", "dropped_pct", "instance_hours")}
                               for s_ in ("reactive", "predictive")}
    json.dump(out, open("results.json", "w"))
    base = out["as"]["static_peak"]["instance_hours"]
    print("LB results (ms): mean / p95 / p99")
    for u, v in out["lb"].items():
        print("util", u)
        for p, r in v.items():
            print("  %-22s %9.0f %9.0f %9.0f %s" % (p, r["mean"], r["p95"], r["p99"], "UNSTABLE" if r["unstable"] else ""))
    print("Auto-scaling (day 3):")
    for s, r in out["as"].items():
        print("%-16s sale_viol=%2d surge_viol=%2d" % (s, r["viol_sale"], r["viol_surge"]))
        print("%-16s hrs=%7.1f cost=%5.1f%% meanutil=%5.1f maxutil=%6.1f slo_min=%4d over_min=%4d drop=%5.2f%% worstp95=%7.0f" % (
            s, r["instance_hours"], 100 * r["instance_hours"] / base, r["mean_util_pct"], r["max_util_pct"],
            r["slo_violation_min"], r["overload_min"], r["dropped_pct"], r["worst_p95_ms"]))
    print("Sensitivity to warm-up (minutes): slo_violation_min / dropped_pct / instance_hours")
    for w, v in out["sens"].items():
        print(w, {k: (r["slo_violation_min"], round(r["dropped_pct"], 2), round(r["instance_hours"], 1)) for k, r in v.items()})
